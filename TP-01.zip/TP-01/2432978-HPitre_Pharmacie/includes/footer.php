<head>
    <link rel="stylesheet" href="assets/site.css" />
</head>
        <footer>
          &copy; <?php echo date("Y"); ?> | Super-Drogue. Tous droits réservés | Par Henri Pitre
        </footer>
    </div>
</body>
</html>